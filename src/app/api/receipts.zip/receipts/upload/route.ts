import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, calcPoints, calcTier } from '@/lib/auth'

function normalizeReceiptText(text: string): string {
  return text
    .replace(/\r\n?/g, '\n')
    .replace(/[\u066B\u066C\u066C\u066B\u066C\u066B]/g, '.')
    .replace(/[*#|]/g, '')
    .replace(/[\u2009\u202F\u00A0]/g, ' ')
    .replace(/,/g, '')
    .replace(/\s+/g, ' ')
}

function getReceiptLines(text: string): string[] {
  return normalizeReceiptText(text)
    .split(/\n+/)
    .map(line => line.replace(/\s+/g, ' ').trim())
    .filter(Boolean)
}

function parseReceiptAmount(text: string): number {
  const normalized = normalizeReceiptText(text)
  const lines = getReceiptLines(normalized)
  
  const headerLine = /description\s+qty\s+price\s+total/i
  const totalLabel = /(?:grand\s*total|total\s*amount|net\s*total|total\s*due|amount\s*due|balance\s*due|invoice\s*total|total|cash)/i
  const subtotalLabel = /(?:subtotal|sub\s*total)/i

  let subtotalCandidate = 0
  let totalCandidate = 0

  console.log('Parsing receipt. Lines found:', lines.length)

  // Scan lines in reverse (totals are usually at bottom)
  for (const line of [...lines].reverse()) {
    if (headerLine.test(line)) continue
    
    const trimmedLine = line.trim()
    if (!trimmedLine) continue
    
    // Extract all numbers (including decimals like 240.01)
    const numbers = Array.from(trimmedLine.matchAll(/([0-9]+\.?[0-9]*)/g))
      .map(m => parseFloat(m[1]))
      .filter(n => !Number.isNaN(n) && n > 0)
    
    if (numbers.length === 0) continue

    console.log(`Line: "${trimmedLine}" | Numbers: ${numbers}`)

    // Check for TOTAL label first (highest priority)
    if (totalLabel.test(trimmedLine)) {
      totalCandidate = numbers[numbers.length - 1]
      console.log('Found TOTAL line, candidate:', totalCandidate)
      if (/^\s*(?:total|cash)\s+/i.test(trimmedLine)) {
        return totalCandidate
      }
    }

    if (subtotalLabel.test(trimmedLine)) {
      subtotalCandidate = Math.max(subtotalCandidate, numbers[numbers.length - 1])
    }
  }

  if (totalCandidate > 0) {
    console.log('Returning totalCandidate:', totalCandidate)
    return totalCandidate
  }
  if (subtotalCandidate > 0) {
    console.log('Returning subtotalCandidate:', subtotalCandidate)
    return subtotalCandidate
  }

  // Fallback: find largest reasonable number
  const allNumbers = Array.from(normalized.matchAll(/([0-9]+\.?[0-9]*)/g))
    .map(m => parseFloat(m[1]))
    .filter(n => !Number.isNaN(n) && n > 0 && n <= 100000)
  
  console.log('All numbers found:', allNumbers)
  const result = allNumbers.length > 0 ? Math.max(...allNumbers) : 0
  console.log('Returning fallback:', result)
  return result
}

export async function POST(req: NextRequest) {
  const { error, session } = await requireAuth()
  if (error) return error

  try {
    const formData = await req.formData()
    const file = formData.get('file') as File | null
    const branchId = formData.get('branchId') as string | null

    if (!file) return NextResponse.json({ error: 'No file provided' }, { status: 400 })

    const userId = (session!.user as any).id
    const bytes = await file.arrayBuffer()
    const base64 = Buffer.from(bytes).toString('base64')

    let ocrText = ''
    let amount = 0
    let receiptNumber = `RCP-${Date.now()}`

    // ── Google Vision OCR ──
    console.log('GOOGLE_VISION_API_KEY set:', !!process.env.GOOGLE_VISION_API_KEY)
    if (process.env.GOOGLE_VISION_API_KEY) {
      try {
        console.log('Using Google Vision API')
        const visionRes = await fetch(
          `https://vision.googleapis.com/v1/images:annotate?key=${process.env.GOOGLE_VISION_API_KEY}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              requests: [{ image: { content: base64 }, features: [{ type: 'TEXT_DETECTION' }] }],
            }),
          }
        )
        const visionData = await visionRes.json()
        console.log('Vision API response:', { status: visionRes.status, hasData: !!visionData.responses?.[0] })
        
        const ocrTexts: string[] = []

        if (visionData.responses?.[0]?.fullTextAnnotation?.text) {
          ocrTexts.push(visionData.responses[0].fullTextAnnotation.text)
        }
        if (Array.isArray(visionData.responses?.[0]?.textAnnotations)) {
          ocrTexts.push(
            ...visionData.responses[0].textAnnotations
              .map((annotation: any) => annotation.description)
              .filter(Boolean)
          )
        }

        ocrText = ocrTexts.join('\n')
        console.log('Extracted OCR text length:', ocrText.length)
        amount = parseReceiptAmount(ocrText)
        console.log('Parsed amount:', amount)

        // Extract receipt number
        const receiptMatch = ocrText.match(/(?:receipt|invoice|no\.?|#|ref)[.:\s#]*([A-Z0-9-]{4,20})/i)
        if (receiptMatch) receiptNumber = receiptMatch[1]
      } catch (visionErr) {
        console.error('Google Vision API error:', visionErr)
        // Fallback to random if Vision fails
        amount = Math.floor(Math.random() * 500) + 100
        ocrText = `FALLBACK_MODE (Vision API failed): Total ${amount} ETB`
      }
    } else {
      console.log('No GOOGLE_VISION_API_KEY, using dev mode')
      // Dev fallback
      amount = Math.floor(Math.random() * 500) + 100
      ocrText = `DEV_MODE Espresso x2 Cappuccino Total: ${amount} ETB`
    }

    // ── Calculate points from total amount ──
    const tierMultiplier: Record<string, number> = { BRONZE: 1, SILVER: 1.25, GOLD: 1.5, VIP: 2 }
    const userRecord = await prisma.user.findUnique({ where: { id: userId }, select: { tier: true } })
    const multiplier = tierMultiplier[userRecord?.tier || 'BRONZE']

    const basePoints = Math.floor(calcPoints(amount) * multiplier)
    const pointsEarned = basePoints

    if (amount === 0) {
      console.warn('Receipt OCR parse failed', { 
        ocrText: ocrText.slice(0, 2000),
        normalized: normalizeReceiptText(ocrText).slice(0, 2000),
        lines: getReceiptLines(ocrText).slice(0, 20)
      })
      return NextResponse.json({ 
        error: 'Could not read the total amount from your receipt. Please make sure the total is clearly visible and try again.',
        debug: {
          ocrTextLength: ocrText.length,
          firstChars: ocrText.slice(0, 200),
          lineCount: getReceiptLines(ocrText).length
        }
      }, { status: 422 })
    }

    // ── Fraud Detection ──
    const fraudReasons: string[] = []
    let fraudScore = 0

    if (amount > 5000) { fraudReasons.push('Unusually high amount'); fraudScore += 0.4 }
    if (amount < 20) { fraudReasons.push('Suspiciously low amount'); fraudScore += 0.3 }

    const recentReceipts = await prisma.receipt.count({
      where: { userId, createdAt: { gte: new Date(Date.now() - 60 * 60 * 1000) } },
    })
    if (recentReceipts >= 3) { fraudReasons.push('Multiple receipts in short time'); fraudScore += 0.4 }
    else if (recentReceipts >= 2) { fraudScore += 0.2 }

    const sameReceiptOtherUser = await prisma.receipt.findFirst({
      where: { receiptNumber, userId: { not: userId } },
    })
    if (sameReceiptOtherUser) { fraudReasons.push('Receipt already used by another account'); fraudScore = 1.0 }

    fraudScore = Math.min(1.0, fraudScore)

    const duplicate = await prisma.receipt.findFirst({ where: { userId, receiptNumber } })
    if (duplicate) return NextResponse.json({ error: 'Receipt already submitted' }, { status: 409 })

    const branch = branchId
      ? await prisma.branch.findUnique({ where: { id: branchId } })
      : await prisma.branch.findFirst()

    if (!branch) return NextResponse.json({ error: 'Branch not found' }, { status: 404 })

    const receipt = await prisma.receipt.create({
      data: {
        receiptNumber,
        userId,
        branchId: branch.id,
        amount,
        pointsEarned,
        ocrData: { rawText: ocrText, basePoints, multiplier },
        status: fraudScore >= 1.0 ? 'FLAGGED' : 'PENDING',
        fraudScore,
        fraudReasons,
      },
    })

    // Auto-approve all receipts that are not flagged for fraud
    if (receipt.status !== 'FLAGGED') {
      await prisma.$transaction([
        prisma.receipt.update({ where: { id: receipt.id }, data: { status: 'APPROVED', reviewedAt: new Date() } }),
        prisma.user.update({ where: { id: userId }, data: { points: { increment: pointsEarned }, totalSpent: { increment: amount } } }),
        prisma.transaction.create({
          data: { userId, type: 'earned', amount: pointsEarned, description: `Receipt at ${branch.name} for ${amount} ETB`, reference: `receipt:${receipt.id}` },
        }),
        prisma.notification.create({
          data: { userId, type: 'points', title: 'Points Added!', message: `+${pointsEarned} pts from your receipt (${amount} ETB)` },
        }),
      ])

      const updatedUser = await prisma.user.findUnique({ where: { id: userId }, select: { points: true, tier: true } })
      const newTier = calcTier(updatedUser!.points)
      if (newTier !== updatedUser!.tier) {
        await prisma.user.update({ where: { id: userId }, data: { tier: newTier as any } })
        await prisma.notification.create({
          data: { userId, type: 'tier', title: '🎉 Tier Upgrade!', message: `You've reached ${newTier} tier!` },
        })
      }
    }

    return NextResponse.json({
      receipt: {
        id: receipt.id,
        amount,
        pointsEarned,
        status: receipt.status,
        receiptNumber,
        branch: branch.name,
      },
    })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 })
  }
}
